<?php

namespace SystmDev;

use hcf\HCFLoader;
use hcf\player\Player as PlayerPlayer;
use SystmDev\Command\SkyBaseCommand;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\world\Position;
use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use pocketmine\utils\SingletonTrait;

class Loader extends PluginBase implements Listener
{
    private array $positions = [];
    private Menus $menus;
    use SingletonTrait;

    public function onLoad(): void
    {
        self::setInstance($this);
    }

    public function onEnable(): void
    {
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
        $this->menus = new Menus();
        $this->getServer()->getCommandMap()->register("skybase", new SkyBaseCommand);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("SkyBase plugin enabled!");
        $this->saveConfig();
        $this->saveDefaultConfig();
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void
{
    $player = $event->getPlayer();
    $item = $event->getItem();

    if ($item->getCustomName() === "§3SkyBase Selector") {
        $position = $event->getBlock()->getPosition();

        if (!$this->isAllowZone($position, $player)) {
            $player->sendMessage("§cNo puedes crear una SkyBase en esta zona.");
            return;
        }

        if ($event->getAction() === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
            $this->positions[$player->getName()]['pos1'] = $position;
            $player->sendMessage("§aFirst position placed");
        } elseif ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            $this->positions[$player->getName()]['pos2'] = $position;
            $player->sendMessage("§aSecond position placed");

            if (isset($this->positions[$player->getName()]['pos1'])) {
                $pos1 = $this->positions[$player->getName()]['pos1'];
                $pos2 = $this->positions[$player->getName()]['pos2'];

                $sizeX = abs($pos1->getX() - $pos2->getX()) + 1;
                $sizeZ = abs($pos1->getZ() - $pos2->getZ()) + 1;

                if ($sizeX > 50 || $sizeZ > 50) {
                    $player->sendMessage("§cNo se pudo crear la SkyBase porque la selección es mayor a 50 bloques.");
                    return;
                }

                $this->menus->openColorSelectionMenu($player);
            }
        }
    }
}

    public function runSkyBase(Player $player): void
{
    if (!isset($this->positions[$player->getName()]['pos1']) || !isset($this->positions[$player->getName()]['pos2'])) {
        $player->sendMessage("§cNo se pudo crear la SkyBase porque las posiciones no están definidas.");
        return;
    }

    $pos1 = $this->positions[$player->getName()]['pos1'];
    $pos2 = $this->positions[$player->getName()]['pos2'];
    if (!$this->isAllowZone($pos1, $player) || !$this->isAllowZone($pos2, $player)) {
        $player->sendMessage("§cNo puedes crear la SkyBase en esta zona.");
        return;
    }

    SkyBase::run(
        $player->getWorld(),
        $pos1,
        $pos2,
        $this->menus->getWoolColor(),
        $this->menus->getGlassColor()
    );
    $player->sendMessage("§aSkyBase creada.");
}
    
   private function isAllowZone(Position $p,Player $player):bool{
        if(!class_exists(HCFLoader::class))return true;
        $claim = HCFLoader::getInstance()->getClaimManager()->insideClaim($p);
        if($claim === null){
            if($p->distance($this->getServer()->getWorldManager()->getDefaultWorld()->getSafeSpawn()->asVector3()) < 400)return false;
        }else{
            if(in_array($claim->getType(), ['spawn', 'road', 'koth', 'citadel', 'custom', 'bank']))return false;
            if($player instanceof PlayerPlayer && $player->getSession()->getFaction()!==$claim->getName())return false;
        }
        return true;
    }
}